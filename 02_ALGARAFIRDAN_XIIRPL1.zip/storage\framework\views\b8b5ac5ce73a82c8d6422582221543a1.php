<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Area Parkir</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="form-page">
    <div class="form-card">
        <h1>Tambah Area Parkir</h1>
        <p>Isi data area parkir baru.</p>

        <form method="POST" action="<?php echo e(route('area-parkir.store')); ?>" class="form-grid">
            <?php echo csrf_field(); ?>
            <label>
                Nama Area
                <input type="text" name="nama_area" value="<?php echo e(old('nama_area')); ?>" required>
                <?php $__errorArgs = ['nama_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Kapasitas
                <input type="number" name="kapasitas" value="<?php echo e(old('kapasitas')); ?>" min="1" required>
                <?php $__errorArgs = ['kapasitas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <div class="form-actions">
                <a class="btn-ghost" href="<?php echo e(route('area-parkir.index')); ?>">Kembali</a>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/area-parkir/create.blade.php ENDPATH**/ ?>