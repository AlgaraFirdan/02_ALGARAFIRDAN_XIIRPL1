<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>User Management</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="parkir-shell">
    <aside class="sidebar">
        <div class="brand"><div class="brand-dot">P</div><div class="brand-title">Precision Flow</div></div>
        <nav class="menu">
            <a class="menu-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <a class="menu-item active" href="<?php echo e(route('users.index')); ?>">User Management</a>
            <a class="menu-item" href="<?php echo e(route('tarif-parkir.index')); ?>">Tarif Parkir</a>
            <a class="menu-item" href="<?php echo e(route('area-parkir.index')); ?>">Area Parkir</a>
            <a class="menu-item" href="<?php echo e(route('kendaraan.index')); ?>">Kendaraan</a>
            <a class="menu-item" href="<?php echo e(route('log-aktivitas.index')); ?>">Log Aktivitas</a>
        </nav>
    </aside>

    <main class="main-content">
        <section class="heading-block"><h1>User Management</h1><p>Kelola akun admin, petugas, dan owner.</p></section>
        <?php if(session('success')): ?><div class="alert-success"><?php echo e(session('success')); ?></div><?php endif; ?>

        <section class="table-card">
            <div class="table-head">
                <h2>Daftar User</h2>
                <form class="table-tools" method="GET" action="<?php echo e(route('users.index')); ?>">
                    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Cari nama/username...">
                    <button type="submit">Cari</button>
                    <a class="btn-primary" href="<?php echo e(route('users.create')); ?>">+ Tambah User</a>
                </form>
            </div>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>ID</th><th>NAMA</th><th>USERNAME</th><th>ROLE</th><th>STATUS</th><th>AKSI</th></tr></thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->id_user); ?></td>
                            <td><?php echo e($item->nama); ?></td>
                            <td><?php echo e($item->username); ?></td>
                            <td><?php echo e(strtoupper($item->role)); ?></td>
                            <td><span class="badge <?php echo e((int) $item->status_aktif === 1 ? 'done' : 'parked'); ?>"><?php echo e((int) $item->status_aktif === 1 ? 'AKTIF' : 'NONAKTIF'); ?></span></td>
                            <td>
                                <div class="row-actions">
                                    <a class="btn-ghost" href="<?php echo e(route('users.edit', $item->id_user)); ?>">Edit</a>
                                    <form method="POST" action="<?php echo e(route('users.destroy', $item->id_user)); ?>" onsubmit="return confirm('Hapus user ini?')">
                                        <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                        <button class="btn-danger" type="submit">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr><td colspan="6" class="empty-row">Belum ada data user.</td></tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/users/index.blade.php ENDPATH**/ ?>