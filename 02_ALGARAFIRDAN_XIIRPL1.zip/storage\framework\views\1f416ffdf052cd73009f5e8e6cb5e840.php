<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tarif Parkir</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="parkir-shell">
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-dot">P</div>
            <div class="brand-title">Precision Flow</div>
        </div>

        <nav class="menu">
            <a class="menu-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <a class="menu-item" href="<?php echo e(route('users.index')); ?>">User Management</a>
            <a class="menu-item active" href="<?php echo e(route('tarif-parkir.index')); ?>">Tarif Parkir</a>
            <a class="menu-item" href="<?php echo e(route('area-parkir.index')); ?>">Area Parkir</a>
            <a class="menu-item" href="<?php echo e(route('kendaraan.index')); ?>">Kendaraan</a>
            <a class="menu-item" href="<?php echo e(route('log-aktivitas.index')); ?>">Log Aktivitas</a>
        </nav>
    </aside>

    <main class="main-content">
        <section class="heading-block">
            <h1>Tarif Parkir</h1>
            <p>Kelola tarif kendaraan per jam secara dinamis.</p>
        </section>

        <?php if(session('success')): ?>
            <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <section class="table-card">
            <div class="table-head">
                <h2>Daftar Tarif</h2>
                <form class="table-tools" method="GET" action="<?php echo e(route('tarif-parkir.index')); ?>">
                    <input type="text" name="q" value="<?php echo e($q); ?>" placeholder="Cari jenis kendaraan...">
                    <button type="submit">Cari</button>
                    <a class="btn-primary" href="<?php echo e(route('tarif-parkir.create')); ?>">+ Tambah Tarif</a>
                </form>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>JENIS KENDARAAN</th>
                        <th>TARIF / JAM</th>
                        <th>STATUS</th>
                        <th>AKSI</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $tarifParkir; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item->id_tarif); ?></td>
                            <td><?php echo e($item->jenis_kendaraan); ?></td>
                            <td>Rp <?php echo e(number_format((float) $item->tarif_per_jam, 0, ',', '.')); ?></td>
                            <td>
                                <span class="badge <?php echo e((int) $item->status_aktif === 1 ? 'done' : 'parked'); ?>">
                                    <?php echo e((int) $item->status_aktif === 1 ? 'AKTIF' : 'NONAKTIF'); ?>

                                </span>
                            </td>
                            <td>
                                <div class="row-actions">
                                    <a class="btn-ghost" href="<?php echo e(route('tarif-parkir.edit', $item->id_tarif)); ?>">Edit</a>
                                    <form method="POST" action="<?php echo e(route('tarif-parkir.destroy', $item->id_tarif)); ?>" onsubmit="return confirm('Hapus tarif ini?')">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button class="btn-danger" type="submit">Hapus</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="5" class="empty-row">Belum ada data tarif parkir.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="table-foot">
                <p>Total data: <?php echo e($tarifParkir->total()); ?></p>
                <div class="pagination">
                    <?php if($tarifParkir->onFirstPage()): ?>
                        <span class="page-disabled">&lsaquo;</span>
                    <?php else: ?>
                        <a href="<?php echo e($tarifParkir->previousPageUrl()); ?>">&lsaquo;</a>
                    <?php endif; ?>

                    <?php for($page = 1; $page <= $tarifParkir->lastPage(); $page++): ?>
                        <a href="<?php echo e($tarifParkir->url($page)); ?>" class="<?php echo e($tarifParkir->currentPage() === $page ? 'active' : ''); ?>"><?php echo e($page); ?></a>
                    <?php endfor; ?>

                    <?php if($tarifParkir->hasMorePages()): ?>
                        <a href="<?php echo e($tarifParkir->nextPageUrl()); ?>">&rsaquo;</a>
                    <?php else: ?>
                        <span class="page-disabled">&rsaquo;</span>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/tarif-parkir/index.blade.php ENDPATH**/ ?>