<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login - Precision Flow</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="login-body">
<div class="login-atmosphere"></div>

<main class="login-wrapper">
    <section class="login-card">
        <div class="login-logo">P</div>
        <h1>Selamat Datang Di Flow</h1>
        <p>Enter your credentials to access the intelligent monolith.</p>

        <form method="POST" action="<?php echo e(route('login.process')); ?>" class="login-form">
            <?php echo csrf_field(); ?>

            <label for="credential">EMAIL OR USERNAME</label>
            <input
                id="credential"
                type="text"
                name="credential"
                value="<?php echo e(old('credential')); ?>"
                placeholder="john.doe@precisionflow.com"
                required
                autofocus
            >

            <label for="password">PASSWORD</label>
            <input
                id="password"
                type="password"
                name="password"
                placeholder="••••••••"
                required
            >

            <?php $__errorArgs = ['credential'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <div class="login-error"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

            <button type="submit" class="login-btn">Login</button>
        </form>
    </section>
</main>

<footer class="login-footer">&copy; 2026 SMART PARKING SYSTEM</footer>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/auth/login.blade.php ENDPATH**/ ?>