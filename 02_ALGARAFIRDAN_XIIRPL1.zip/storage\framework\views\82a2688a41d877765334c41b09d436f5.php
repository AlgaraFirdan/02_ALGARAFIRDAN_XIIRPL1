<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan Rekap Transaksi</title>
    <style>
        body {
            font-family: DejaVu Sans, sans-serif;
            font-size: 12px;
            color: #111;
        }

        .header {
            margin-bottom: 16px;
        }

        .title {
            font-size: 18px;
            font-weight: 700;
            margin: 0;
        }

        .subtitle {
            margin: 4px 0;
            color: #444;
        }

        .summary {
            margin: 12px 0;
            border: 1px solid #ddd;
            padding: 10px;
        }

        .summary-row {
            margin: 4px 0;
        }

        table {
            width: 100%;
            border-collapse: collapse;
        }

        th, td {
            border: 1px solid #333;
            padding: 6px;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #f0f4f8;
        }

        .right {
            text-align: right;
        }

        .center {
            text-align: center;
        }

        .footer {
            margin-top: 12px;
            font-size: 10px;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="header">
        <h1 class="title">Laporan Rekap Transaksi Parkir</h1>
        <p class="subtitle">Periode: <?php echo e($filters['start']); ?> s/d <?php echo e($filters['end']); ?></p>
        <p class="subtitle">Dicetak: <?php echo e($printedAt->format('d M Y H:i')); ?></p>
    </div>

    <div class="summary">
        <div class="summary-row"><strong>Total Transaksi:</strong> <?php echo e(number_format($summary['total_transaksi'])); ?></div>
        <div class="summary-row"><strong>Total Pendapatan:</strong> Rp <?php echo e(number_format($summary['total_pendapatan'], 0, ',', '.')); ?></div>
        <div class="summary-row"><strong>Rata Durasi:</strong> <?php echo e(number_format($summary['rata_durasi_jam'], 2, ',', '.')); ?> jam</div>
    </div>

    <table>
        <thead>
        <tr>
            <th class="center">No</th>
            <th>Plat</th>
            <th>Jenis</th>
            <th>Area</th>
            <th>Masuk</th>
            <th>Keluar</th>
            <th class="center">Durasi</th>
            <th class="right">Total</th>
        </tr>
        </thead>
        <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td class="center"><?php echo e($index + 1); ?></td>
                <td><?php echo e($item->kendaraan?->plat_nomor ?? '-'); ?></td>
                <td><?php echo e($item->kendaraan?->jenis_kendaraan ?? '-'); ?></td>
                <td><?php echo e($item->areaParkir?->nama_area ?? '-'); ?></td>
                <td><?php echo e($item->waktu_masuk?->format('d M Y H:i') ?? '-'); ?></td>
                <td><?php echo e($item->waktu_keluar?->format('d M Y H:i') ?? '-'); ?></td>
                <td class="center"><?php echo e($item->durasi_jam); ?> jam</td>
                <td class="right">Rp <?php echo e(number_format((float) $item->biaya_total, 0, ',', '.')); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="8" class="center">Tidak ada transaksi pada rentang ini.</td>
            </tr>
        <?php endif; ?>
        </tbody>
    </table>

    <div class="footer">
        Precision Flow - Sistem Parkir
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/rekap/pdf.blade.php ENDPATH**/ ?>