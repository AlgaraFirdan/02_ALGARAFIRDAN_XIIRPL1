<!DOCTYPE html>
<html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>Edit Kendaraan</title><?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?></head>
<body class="parkir-body"><div class="form-page"><div class="form-card"><h1>Edit Kendaraan</h1><p>Perbarui detail kendaraan.</p>
<form method="POST" action="<?php echo e(route('kendaraan.update', $item->id_kendaraan)); ?>" class="form-grid"><?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
<label>Plat Nomor<input type="text" name="plat_nomor" value="<?php echo e(old('plat_nomor', $item->plat_nomor)); ?>" required><?php $__errorArgs = ['plat_nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
<label>Jenis Kendaraan<input type="text" name="jenis_kendaraan" value="<?php echo e(old('jenis_kendaraan', $item->jenis_kendaraan)); ?>" required><?php $__errorArgs = ['jenis_kendaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
<label>Warna<input type="text" name="warna" value="<?php echo e(old('warna', $item->warna)); ?>" required><?php $__errorArgs = ['warna'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
<label>Pemilik<input type="text" name="pemilik" value="<?php echo e(old('pemilik', $item->pemilik)); ?>" required><?php $__errorArgs = ['pemilik'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
<label>Penanggung Jawab User<select name="id_user" required><option value="">Pilih user</option><?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><option value="<?php echo e($user->id_user); ?>" <?php if((string) old('id_user', $item->id_user)===(string)$user->id_user): echo 'selected'; endif; ?>><?php echo e($user->nama); ?> (<?php echo e($user->username); ?>)</option><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></select><?php $__errorArgs = ['id_user'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?></label>
<div class="form-actions"><a class="btn-ghost" href="<?php echo e(route('kendaraan.index')); ?>">Kembali</a><button class="btn-primary" type="submit">Update</button></div>
</form></div></div></body></html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/kendaraan/edit.blade.php ENDPATH**/ ?>