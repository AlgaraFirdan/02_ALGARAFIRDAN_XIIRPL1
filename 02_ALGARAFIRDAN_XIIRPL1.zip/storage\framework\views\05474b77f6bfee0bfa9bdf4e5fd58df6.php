<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Precision Flow Dashboard</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="parkir-shell">
    <?php
        $currentUser = auth()->user();
        $roleLabel = match ($currentUser->role) {
            'admin' => 'SYSTEM MANAGER',
            'petugas' => 'PARKING OPERATOR',
            'owner' => 'BUSINESS OWNER',
            default => strtoupper((string) $currentUser->role),
        };
        $avatarInitials = collect(explode(' ', trim((string) $currentUser->nama)))
            ->filter()
            ->take(2)
            ->map(fn ($word) => strtoupper(substr($word, 0, 1)))
            ->implode('');
        if ($avatarInitials === '') {
            $avatarInitials = strtoupper(substr((string) $currentUser->username, 0, 2));
        }
    ?>

    <aside class="sidebar">
        <div class="brand">
            <div class="brand-dot">P</div>
            <div class="brand-title">Precision Flow</div>
        </div>

        <nav class="menu">
            <a class="menu-item active" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <?php if(auth()->user()->role === 'admin'): ?>
                <a class="menu-item" href="<?php echo e(route('users.index')); ?>">User Management</a>
                <a class="menu-item" href="<?php echo e(route('tarif-parkir.index')); ?>">Tarif Parkir</a>
                <a class="menu-item" href="<?php echo e(route('area-parkir.index')); ?>">Area Parkir</a>
                <a class="menu-item" href="<?php echo e(route('kendaraan.index')); ?>">Kendaraan</a>
                <a class="menu-item" href="<?php echo e(route('log-aktivitas.index')); ?>">Log Aktivitas</a>
            <?php endif; ?>

            <?php if(auth()->user()->role === 'petugas'): ?>
                <a class="menu-item" href="<?php echo e(route('transaksi.masuk')); ?>">Input Kendaraan Masuk</a>
                <a class="menu-item" href="<?php echo e(route('transaksi.keluar')); ?>">Transaksi Keluar</a>
                <a class="menu-item" href="<?php echo e(route('transaksi.keluar')); ?>">Cetak Struk</a>
            <?php endif; ?>

            <?php if(auth()->user()->role === 'owner'): ?>
                <a class="menu-item" href="<?php echo e(route('rekap.index')); ?>">Rekap Transaksi</a>
            <?php endif; ?>
        </nav>
    </aside>

    <main class="main-content">
        <header class="topbar">
            <div class="topbar-left"></div>
            <div class="topbar-right">
                <div class="status-chip">
                    <span class="dot"></span>
                    System Online
                </div>
                <div class="date-chip"><?php echo e($todayLabel); ?></div>
                <div class="user-box">
                    <div>
                        <div class="user-name"><?php echo e($currentUser->nama); ?></div>
                        <div class="user-role"><?php echo e($roleLabel); ?></div>
                    </div>
                    <div class="avatar"><?php echo e($avatarInitials); ?></div>
                    <form method="POST" action="<?php echo e(route('logout')); ?>">
                        <?php echo csrf_field(); ?>
                        <button class="logout" type="submit">Logout</button>
                    </form>
                </div>
            </div>
        </header>

        <section class="heading-block">
            <h1>Overview Dashboard</h1>
            <p>Real-time parking statistics for Avenue Core Infrastructure.</p>
        </section>

        <section class="stats-grid">
            <article class="stat-card">
                <span class="icon blue">&#128663;</span>
                <p>TOTAL KENDARAAN</p>
                <h3><?php echo e(number_format($stats['total_kendaraan'])); ?></h3>
            </article>
            <article class="stat-card">
                <span class="icon violet">&#128179;</span>
                <p>TRANSAKSI HARI INI</p>
                <h3><?php echo e($stats['transaksi_harian']); ?></h3>
            </article>
            <article class="stat-card">
                <span class="icon green">&#10145;</span>
                <p>KENDARAAN MASUK</p>
                <h3><?php echo e($stats['kendaraan_masuk']); ?></h3>
            </article>
            <article class="stat-card">
                <span class="icon red">&#11013;</span>
                <p>KENDARAAN KELUAR</p>
                <h3><?php echo e($stats['kendaraan_keluar']); ?></h3>
            </article>
        </section>

        <section class="table-card">
            <div class="table-head">
                <h2>Transaksi Terbaru</h2>
                <form class="table-tools" method="GET" action="<?php echo e(route('dashboard')); ?>">
                    <input
                        type="text"
                        name="q"
                        value="<?php echo e($filters['q']); ?>"
                        placeholder="Cari plat nomor..."
                    >
                    <select name="status" aria-label="Filter status">
                        <option value="">Semua Status</option>
                        <option value="masuk" <?php if($filters['status'] === 'masuk'): echo 'selected'; endif; ?>>Masuk / Parkir</option>
                        <option value="keluar" <?php if($filters['status'] === 'keluar'): echo 'selected'; endif; ?>>Keluar / Selesai</option>
                    </select>
                    <button type="submit">Filter</button>
                </form>
            </div>

            <div class="table-wrap">
                <table>
                    <thead>
                    <tr>
                        <th>NO</th>
                        <th>PLAT NOMOR</th>
                        <th>JENIS</th>
                        <th>JAM MASUK</th>
                        <th>JAM KELUAR</th>
                        <th>TOTAL BAYAR</th>
                        <th>STATUS</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php $__empty_1 = true; $__currentLoopData = $transaksiTerbaru; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($item['no']); ?></td>
                            <td><span class="plate"><?php echo e($item['plat_nomor']); ?></span></td>
                            <td><?php echo e($item['jenis']); ?></td>
                            <td><?php echo e($item['jam_masuk']); ?></td>
                            <td><?php echo e($item['jam_keluar']); ?></td>
                            <td class="payment"><?php echo e($item['total_bayar']); ?></td>
                            <td>
                                <span class="badge <?php echo e($item['status'] === 'selesai' ? 'done' : 'parked'); ?>">
                                    <?php echo e(strtoupper($item['status'])); ?>

                                </span>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="empty-row">Belum ada data transaksi.</td>
                        </tr>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>

            <div class="table-foot">
                <p>Menampilkan <?php echo e($transaksiTerbaru->count()); ?> dari <?php echo e($transaksiTerbaru->total()); ?> transaksi</p>
                <div class="pagination">
                    <?php if($transaksiTerbaru->onFirstPage()): ?>
                        <span class="page-disabled">&lsaquo;</span>
                    <?php else: ?>
                        <a href="<?php echo e($transaksiTerbaru->previousPageUrl()); ?>">&lsaquo;</a>
                    <?php endif; ?>

                    <?php for($page = 1; $page <= $transaksiTerbaru->lastPage(); $page++): ?>
                        <a
                            href="<?php echo e($transaksiTerbaru->url($page)); ?>"
                            class="<?php echo e($transaksiTerbaru->currentPage() === $page ? 'active' : ''); ?>"
                        >
                            <?php echo e($page); ?>

                        </a>
                    <?php endfor; ?>

                    <?php if($transaksiTerbaru->hasMorePages()): ?>
                        <a href="<?php echo e($transaksiTerbaru->nextPageUrl()); ?>">&rsaquo;</a>
                    <?php else: ?>
                        <span class="page-disabled">&rsaquo;</span>
                    <?php endif; ?>
                </div>
            </div>
        </section>

        <footer class="footer">&copy; 2023 PRECISION FLOW MANAGEMENT - INTELLIGENCE IN MOTION</footer>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/dashboard.blade.php ENDPATH**/ ?>