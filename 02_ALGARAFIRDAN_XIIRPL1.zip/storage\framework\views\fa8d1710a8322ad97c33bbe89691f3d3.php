<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah Tarif Parkir</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="form-page">
    <div class="form-card">
        <h1>Tambah Tarif Parkir</h1>
        <p>Isi tarif per jam untuk jenis kendaraan tertentu.</p>

        <form method="POST" action="<?php echo e(route('tarif-parkir.store')); ?>" class="form-grid">
            <?php echo csrf_field(); ?>
            <label>
                Jenis Kendaraan
                <input type="text" name="jenis_kendaraan" value="<?php echo e(old('jenis_kendaraan')); ?>" required>
                <?php $__errorArgs = ['jenis_kendaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Tarif Per Jam
                <input type="number" name="tarif_per_jam" value="<?php echo e(old('tarif_per_jam')); ?>" min="0" step="100" required>
                <?php $__errorArgs = ['tarif_per_jam'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <label>
                Status
                <select name="status_aktif" required>
                    <option value="1" <?php if(old('status_aktif', '1') === '1'): echo 'selected'; endif; ?>>Aktif</option>
                    <option value="0" <?php if(old('status_aktif') === '0'): echo 'selected'; endif; ?>>Nonaktif</option>
                </select>
                <?php $__errorArgs = ['status_aktif'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </label>

            <div class="form-actions">
                <a class="btn-ghost" href="<?php echo e(route('tarif-parkir.index')); ?>">Kembali</a>
                <button type="submit" class="btn-primary">Simpan</button>
            </div>
        </form>
    </div>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/tarif-parkir/create.blade.php ENDPATH**/ ?>