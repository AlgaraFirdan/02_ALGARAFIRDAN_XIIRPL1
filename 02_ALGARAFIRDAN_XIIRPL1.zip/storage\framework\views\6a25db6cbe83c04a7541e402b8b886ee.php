<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Transaksi Kendaraan Keluar</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="parkir-shell">
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-dot">P</div>
            <div class="brand-title">Precision Flow</div>
        </div>

        <nav class="menu">
            <a class="menu-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <a class="menu-item" href="<?php echo e(route('transaksi.masuk')); ?>">Input Kendaraan Masuk</a>
            <a class="menu-item active" href="<?php echo e(route('transaksi.keluar')); ?>">Transaksi Keluar</a>
        </nav>
    </aside>

    <main class="main-content">
        <?php if(session('success')): ?>
            <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <section class="heading-row">
            <div>
                <h1 class="page-title">Transaksi Kendaraan Keluar</h1>
                <p class="page-subtitle">Cari kendaraan, hitung biaya, dan cetak struk</p>
                <div class="tab-links">
                    <a href="<?php echo e(route('transaksi.masuk')); ?>">Input Kendaraan Masuk</a>
                    <a class="active" href="<?php echo e(route('transaksi.keluar')); ?>">Transaksi Kendaraan Keluar</a>
                </div>
            </div>
            <div class="current-date-box">
                <small>CURRENT DATE</small>
                <strong><?php echo e($nowLabel); ?></strong>
            </div>
        </section>

        <section class="outbound-grid">
            <?php
                $receipt = $lastStruk ?? $transaksi;
                $receiptTotal = $lastStruk
                    ? (int) round((float) $lastStruk->biaya_total)
                    : ($kalkulasi['total'] ?? 0);
                $receiptMasuk = $receipt?->waktu_masuk?->format('H:i') ?? '-';
                $receiptKeluar = $lastStruk
                    ? ($lastStruk->waktu_keluar?->format('H:i') ?? '-')
                    : ($kalkulasi ? $kalkulasi['waktu_keluar']->format('H:i') : '-');
                $receiptNo = $receipt
                    ? 'PF-TRX-' . str_pad((string) $receipt->id_parkir, 6, '0', STR_PAD_LEFT)
                    : 'PF-TRX-102433';
            ?>

            <div class="outbound-main">
                <div class="step-box">
                    <h3><span>1</span> Cari Kendaraan</h3>
                    <form method="GET" action="<?php echo e(route('transaksi.keluar')); ?>" class="search-row">
                        <input name="q" value="<?php echo e($q); ?>" type="text" placeholder="Masukkan Plat Nomor (Contoh: B 1234 ABC)">
                        <button class="btn-primary" type="submit">Cari</button>
                    </form>
                    <?php $__errorArgs = ['q'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    <?php if($q !== '' && ! $transaksi): ?>
                        <small class="text-muted">Kendaraan dengan plat tersebut tidak ditemukan di parkir aktif.</small>
                    <?php endif; ?>
                </div>

                <div class="step-box">
                    <h3><span>2</span> Detail Kendaraan</h3>
                    <div class="detail-grid">
                        <div>
                            <label>Plat Nomor</label>
                            <p><?php echo e($transaksi?->kendaraan?->plat_nomor ?? '-'); ?></p>
                        </div>
                        <div>
                            <label>Jenis Kendaraan</label>
                            <p><?php echo e($transaksi?->kendaraan?->jenis_kendaraan ?? '-'); ?></p>
                        </div>
                        <div>
                            <label>Area Parkir</label>
                            <p><?php echo e($transaksi?->areaParkir?->nama_area ?? '-'); ?></p>
                        </div>
                        <div>
                            <label>Waktu Masuk</label>
                            <p><?php echo e($transaksi?->waktu_masuk?->format('d M Y, H:i:s') ?? '-'); ?></p>
                        </div>
                    </div>
                </div>

                <div class="step-box">
                    <h3><span>3</span> Perhitungan Otomatis</h3>
                    <div class="detail-grid compact">
                        <div>
                            <label>Waktu Keluar</label>
                            <p><?php echo e($kalkulasi ? $kalkulasi['waktu_keluar']->format('H:i:s') : '-'); ?></p>
                        </div>
                        <div>
                            <label>Durasi</label>
                            <p><?php echo e($kalkulasi['durasi_label'] ?? '-'); ?></p>
                        </div>
                        <div>
                            <label>Tarif / Jam</label>
                            <p>Rp <?php echo e(number_format($tarifPerJam, 0, ',', '.')); ?></p>
                        </div>
                    </div>

                    <div class="total-panel">
                        <div>
                            <small>TOTAL BAYAR</small>
                            <h2><?php echo e($kalkulasi ? 'Rp ' . number_format($kalkulasi['total'], 0, ',', '.') : 'Rp 0'); ?></h2>
                        </div>
                        <div class="total-actions">
                            <?php if($transaksi): ?>
                                <form method="POST" action="<?php echo e(route('transaksi.keluar.proses', $transaksi->id_parkir)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="btn-white-pill" type="submit">Proses &amp; Cetak Struk</button>
                                </form>
                            <?php else: ?>
                                <button class="btn-white-pill" type="button" disabled>Proses &amp; Cetak Struk</button>
                            <?php endif; ?>
                            <a class="btn-ghost dark-pill" href="<?php echo e(route('transaksi.keluar')); ?>">Reset</a>
                        </div>
                    </div>
                </div>
            </div>

            <aside class="receipt-card">
                <div class="receipt-head">
                    <h3>PRECISION FLOW</h3>
                    <p>SMART PARKING SOLUTIONS</p>
                </div>
                <div class="receipt-line"></div>
                <div class="receipt-body">
                    <div><span>No. Struk:</span><b><?php echo e($receiptNo); ?></b></div>
                    <div><span>Petugas:</span><b><?php echo e(strtoupper((string) auth()->user()->username)); ?></b></div>
                    <div><span>Kendaraan</span><b><?php echo e($receipt?->kendaraan?->plat_nomor ?? '-'); ?></b></div>
                    <div><span>Tipe</span><b><?php echo e($receipt?->kendaraan?->jenis_kendaraan ?? '-'); ?></b></div>
                    <div><span>Masuk</span><b><?php echo e($receiptMasuk); ?></b></div>
                    <div><span>Keluar</span><b><?php echo e($receiptKeluar); ?></b></div>
                </div>
                <div class="receipt-line"></div>
                <div class="receipt-total">
                    <span>TOTAL</span>
                    <strong><?php echo e('Rp ' . number_format($receiptTotal, 0, ',', '.')); ?></strong>
                </div>
                <?php if($lastStruk): ?>
                    <div class="total-actions" style="margin-top: 16px; justify-content: flex-end;">
                        <button class="btn-primary" type="button" onclick="window.print()">Cetak Ulang Struk</button>
                    </div>
                <?php endif; ?>
            </aside>

        </section>
    </main>
</div>
<?php if($autoPrint && $lastStruk): ?>
    <script>
        window.addEventListener('load', function () {
            window.print();
        });
    </script>
<?php endif; ?>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/transaksi/keluar.blade.php ENDPATH**/ ?>