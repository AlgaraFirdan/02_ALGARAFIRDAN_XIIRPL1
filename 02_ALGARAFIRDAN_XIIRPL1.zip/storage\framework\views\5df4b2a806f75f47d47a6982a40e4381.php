<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Input Kendaraan Masuk</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="parkir-shell">
    <aside class="sidebar">
        <div class="brand">
            <div class="brand-dot">P</div>
            <div class="brand-title">Precision Flow</div>
        </div>

        <nav class="menu">
            <a class="menu-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
            <a class="menu-item active" href="<?php echo e(route('transaksi.masuk')); ?>">Input Kendaraan Masuk</a>
            <a class="menu-item" href="<?php echo e(route('transaksi.keluar')); ?>">Transaksi Keluar</a>
            <a class="menu-item" href="<?php echo e(route('transaksi.keluar')); ?>">Cetak Struk</a>
        </nav>
    </aside>

    <main class="main-content">
        <section class="heading-row">
            <div>
                <h1 class="page-title">Input Kendaraan Masuk</h1>
                <p class="page-subtitle">Masukkan data kendaraan yang masuk ke area parkir</p>
            </div>
            <a class="link-back" href="<?php echo e(route('dashboard')); ?>">&larr; Kembali ke Daftar</a>
        </section>

        <?php if(session('success')): ?>
            <div class="alert-success"><?php echo e(session('success')); ?></div>
        <?php endif; ?>

        <section class="inbound-card">
            <div class="inbound-header">
                <div class="square-icon">&#9998;</div>
                <div>
                    <h2>Form Kendaraan</h2>
                    <p>Lengkapi field dibawah ini secara akurat</p>
                </div>
            </div>

            <form method="POST" action="<?php echo e(route('transaksi.masuk.store')); ?>" class="inbound-form">
                <?php echo csrf_field(); ?>
                <div>
                    <label for="plat_nomor">Plat Nomor</label>
                    <input id="plat_nomor" name="plat_nomor" type="text" value="<?php echo e(old('plat_nomor')); ?>" placeholder="B 1234 XYZ" required>
                    <?php $__errorArgs = ['plat_nomor'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="waktu_masuk">Waktu Masuk (Auto)</label>
                    <input id="waktu_masuk" type="text" value="<?php echo e($autoTime); ?>" readonly>
                </div>

                <div>
                    <label for="jenis_kendaraan">Jenis Kendaraan</label>
                    <select id="jenis_kendaraan" name="jenis_kendaraan" required>
                        <option value="">Pilih jenis</option>
                        <option value="Mobil" <?php if(old('jenis_kendaraan') === 'Mobil'): echo 'selected'; endif; ?>>Mobil</option>
                        <option value="Motor" <?php if(old('jenis_kendaraan') === 'Motor'): echo 'selected'; endif; ?>>Motor</option>
                        <option value="Bus" <?php if(old('jenis_kendaraan') === 'Bus'): echo 'selected'; endif; ?>>Bus</option>
                        <option value="Truk" <?php if(old('jenis_kendaraan') === 'Truk'): echo 'selected'; endif; ?>>Truk</option>
                    </select>
                    <?php $__errorArgs = ['jenis_kendaraan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div>
                    <label for="id_area">Area Parkir</label>
                    <select id="id_area" name="id_area" required>
                        <option value="">Pilih area</option>
                        <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($area->id_area); ?>" <?php if((string) old('id_area') === (string) $area->id_area): echo 'selected'; endif; ?>>
                                <?php echo e($area->nama_area); ?> (<?php echo e($area->kapasitas); ?>)
                            </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ['id_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><small><?php echo e($message); ?></small><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="form-divider"></div>

                <div class="inbound-actions">
                    <button type="reset" class="btn-ghost">Reset</button>
                    <button type="submit" class="btn-primary btn-pill">Simpan Data</button>
                </div>
            </form>
        </section>
    </main>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/transaksi/masuk.blade.php ENDPATH**/ ?>