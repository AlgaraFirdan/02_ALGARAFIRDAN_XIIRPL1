<!DOCTYPE html>
<html lang="id">
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Rekap Transaksi</title>
	<?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="parkir-body">
<div class="parkir-shell">
	<aside class="sidebar">
		<div class="brand">
			<div class="brand-dot">P</div>
			<div class="brand-title">Precision Flow</div>
		</div>
		<nav class="menu">
			<a class="menu-item" href="<?php echo e(route('dashboard')); ?>">Dashboard</a>
			<a class="menu-item active" href="<?php echo e(route('rekap.index')); ?>">Laporan Rekap</a>
		</nav>
	</aside>

	<main class="main-content">
		<section class="heading-block">
			<h1>Rekap Transaksi</h1>
			<p>Rekap transaksi sesuai rentang waktu yang diminta.</p>
		</section>

		<section class="table-card">
			<div class="table-head">
				<h2>Filter Rekap</h2>
				<form class="table-tools" method="GET" action="<?php echo e(route('rekap.index')); ?>">
					<input type="date" name="start" value="<?php echo e($filters['start']); ?>">
					<input type="date" name="end" value="<?php echo e($filters['end']); ?>">
					<button type="submit">Terapkan</button>
					<a
						class="btn-primary"
						href="<?php echo e(route('rekap.pdf', ['start' => $filters['start'], 'end' => $filters['end']])); ?>"
						target="_blank"
					>
						Cetak PDF
					</a>
				</form>
			</div>

			<div class="stats-grid" style="padding: 16px;">
				<article class="stat-card">
					<p>TOTAL TRANSAKSI</p>
					<h3><?php echo e(number_format($summary['total_transaksi'])); ?></h3>
				</article>
				<article class="stat-card">
					<p>TOTAL PENDAPATAN</p>
					<h3>Rp <?php echo e(number_format($summary['total_pendapatan'], 0, ',', '.')); ?></h3>
				</article>
				<article class="stat-card">
					<p>RATA DURASI (JAM)</p>
					<h3><?php echo e(number_format($summary['rata_durasi_jam'], 2, ',', '.')); ?></h3>
				</article>
			</div>

			<div class="table-wrap">
				<table>
					<thead>
					<tr>
						<th>PLAT</th>
						<th>JENIS</th>
						<th>AREA</th>
						<th>MASUK</th>
						<th>KELUAR</th>
						<th>DURASI</th>
						<th>TOTAL</th>
					</tr>
					</thead>
					<tbody>
					<?php $__empty_1 = true; $__currentLoopData = $rekap; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
						<tr>
							<td><?php echo e($item->kendaraan?->plat_nomor ?? '-'); ?></td>
							<td><?php echo e($item->kendaraan?->jenis_kendaraan ?? '-'); ?></td>
							<td><?php echo e($item->areaParkir?->nama_area ?? '-'); ?></td>
							<td><?php echo e($item->waktu_masuk?->format('d M Y H:i') ?? '-'); ?></td>
							<td><?php echo e($item->waktu_keluar?->format('d M Y H:i') ?? '-'); ?></td>
							<td><?php echo e($item->durasi_jam); ?> jam</td>
							<td>Rp <?php echo e(number_format((float) $item->biaya_total, 0, ',', '.')); ?></td>
						</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
						<tr>
							<td colspan="7" class="empty-row">Tidak ada transaksi pada rentang ini.</td>
						</tr>
					<?php endif; ?>
					</tbody>
				</table>
			</div>
		</section>
	</main>
</div>
</body>
</html>
<?php /**PATH C:\laragon\www\UKKGARA\resources\views/rekap/index.blade.php ENDPATH**/ ?>